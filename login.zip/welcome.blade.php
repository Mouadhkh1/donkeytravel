@extends('layout')
@section('title', "Home page")
@section('content')

@endsection
